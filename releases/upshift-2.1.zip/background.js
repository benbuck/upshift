// upshift - Copyright (C) 2011 Benbuck Nason

function updateIcon(tabId) {
	//console.log("get: " + tab.url);
	chrome.pageAction.show(tabId);
}

chrome.tabs.onSelectionChanged.addListener(function(tabId) {
	//console.log("onSelectionChanged: " + tabId);
	updateIcon(tabId);
});

chrome.tabs.getSelected(null, function(tab) {
	//console.log("getSelected: " + tab.id);
	updateIcon(tab.id);
});

chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
	//console.log("onUpdated: " + tabId);
	updateIcon(tabId);
});
