console.log("script");

function init() {
	console.log("popup");
	if (!chrome.tabs) {
		buildPopup(null, "http://usr:pwd@abc.test.co.uk:81/dir/dir.2/dir.3/index.htm?q1=0&&test1&test2=value#top");
		buildPopup(null, "http://www.google.com/search?q=arrow+button+icon&hl=en&safe=off&biw=1680&bih=959&tbs=itp:clipart,isz:l&tbm=isch&source=lnt&sa=X&ei=CYq_TZHoMoXfiALctpGLAw&ved=0CAoQpwUoAQ");
	} else {
		chrome.tabs.getSelected(null, function(tab) {
			console.log("get: " + tab.url);
			buildPopup(tab);
		});
	}
}

function buildPopup(tab, url) {
	if (tab)
		url = tab.url;
	
	var uris = upshift.get(url);
	for (var i = 0, uri; uri = uris[i]; i++) {
		var span = document.createElement('span');
		console.log("span: " + span);
		span.className = i % 2 ? "odd" : "even";
		span.appendChild(document.createTextNode(uri));
		span.addEventListener('click', function (e) {
			var newUri = e.currentTarget.innerText;
			console.log("new URI: " + newUri);
			if (!tab) {
				window.location = newUri;
			} else {
				if (e.shiftKey)
					chrome.windows.create({'url': newUri});
				else if (e.ctrlKey)
					chrome.tabs.create({'url': newUri});
				else
					chrome.tabs.update(tab.id, {'url': newUri});
				window.close();
			}
		});
		document.body.appendChild(span);
	}
}

document.addEventListener('DOMContentLoaded', init());